//
//  FactionsView.swift
//  weatherAI
//
//  Created by 侯天阔 on 2023/4/11.
//

import SwiftUI

struct FactionsView: View {
    var body: some View {
        
        ZStack{
           Image("background2")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
                .opacity(0.9)
        
            VStack(spacing: 20) {
                Text("Factions")
                    .font(.largeTitle)
                    .foregroundColor(.white)
                
                Group {
                    Text("Northern Warlords")
                        .font(.headline)
                        .foregroundColor(Color(red: 0.7, green: 0.7, blue: 0.7))
                    
                    NavigationLink(destination: Wei()) {
                        Text("Wei")
                            .padding(.horizontal, 50)
                            .padding()
                            .foregroundColor(.white)
                            .background(Color.black)
                            .clipShape(Capsule())
                    }
                    .buttonStyle(PlainButtonStyle())
                }
                
                Group {
                    Text("Southern Warlords")
                        .font(.headline)
                        .foregroundColor(Color(red: 0.7, green: 0.7, blue: 0.7))
                    
                    NavigationLink(destination: Shu()) {
                        Text("Shu")
                            .padding(.horizontal, 50)
                            .padding()
                            .foregroundColor(.white)
                            .background(Color.black)
                            .clipShape(Capsule())
                    }
                    .buttonStyle(PlainButtonStyle())
                    
                    NavigationLink(destination: Wu()) {
                        Text("Wu")
                            .padding(.horizontal, 50)
                            .padding()
                            .foregroundColor(.white)
                            .background(Color.black)
                            .clipShape(Capsule())
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
            .padding(/*@START_MENU_TOKEN@*/.vertical, 50.0/*@END_MENU_TOKEN@*/)
            .padding(.horizontal, 30)
            .background(Color.black.opacity(0.5))
            .cornerRadius(30)
            
        

        }

    }
}

struct FactionsView_Previews: PreviewProvider {
    static var previews: some View {
        FactionsView()
    }
}
