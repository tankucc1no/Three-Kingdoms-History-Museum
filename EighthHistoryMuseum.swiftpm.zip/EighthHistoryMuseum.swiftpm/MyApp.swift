import SwiftUI

@main
struct MyApp: App {
    init() {
        AudioPlayer.shared.playBackgroundMusic(filename: "BGM")
    }
    var body: some Scene {
        WindowGroup {
            NewHomepageUI()
        }
    }
}
