//
//  Subtitle.swift
//  weatherAI
//
//  Created by 侯天阔 on 2023/4/5.
//

import Foundation
let subtitleLines = [
    "The Battle of Red Cliffs is a famous battle in Chinese history that took place in the winter of 208-209 AD, during the Three Kingdoms period.",
    "It was a cold winter in ancient China, and the fate of the southern warlords Liu Bei and Sun Quan hung in the balance. The northern warlord Cao Cao had amassed a vast army and set his sights on conquering the south. But little did he know, the Sleeping Dragon had awoken.",
    "Zhu Geliang, the brilliant strategist and advisor to Liu, knew that a direct confrontation with Cao's army would be suicidal. He needed a plan, a cunning scheme to turn the tide of the war.\nHowever, The fateful encounter between Zhu and Zhou, two of the greatest strategists of their time, was fraught with tension and suspicion. They both had their own ideas about how to defeat Cao's army, and neither was willing to yield to the other.",
    "As he sat in his tent, surrounded by maps and scrolls, Zhu pondered his options. Suddenly, an idea struck him - fire. Yes, fire would be his weapon, his secret ace in the hole.\nZhou was quick to point out a major flaw in Zhu's plan: the lack of bows and arrows in their army to set fire to the enemy. Without this crucial element, the plan seemed impossible to execute.",
    "This strategy seems less than ideal. With Cao's well-equipped and well-trained army, the southern warlords quickly found themselves outmatched and outmaneuvered on the battlefield. Soon, the entire south was overrun and fully conquered by Cao.",
    "Congratulations! You chose the real historical direction.\n Zhou was skeptical at first, but he could see the determination and intelligence in Zhu's eyes. He knew that this was a man who could be trusted, even in the face of seemingly insurmountable obstacles.\nAnd then the famous story -- Borrowing Arrows with Thatched Boats happened.",
    "Zhu ordered his soldiers to disguise their boats with thatched straw, sail towards the enemy's base, and taunt them into firing arrows at the boats. After that, the boats were quickly retrieved, and the arrows collected and used to replenish their own supply. The enemy was left bewildered, with no idea how their arrows had ended up in the hands of their opponents.\nThis daring tactic was a pivotal moment in the battle, replenishing the armament for the subsequent war.",
    "The day of the battle arrived, and the two armies faced each other across the Yangtze River. Facing the massive and imposing navy from Cao, Zhu ordered his troops to light the arrows on fire and shoot them towards the enemy, while another group of ships, filled with brave soldiers, launched a surprise attack from the shore.",
    "The northern forces were caught off guard, and chaos ensued. The sound of clashing swords and the smell of burning wood filled the air. Zhu watched from the shore, his heart pounding with excitement and fear.",
    "For hours, the battle raged on, with both sides fighting fiercely for their lives. But in the end, it was Zhu's genius plan that won the day.\nCao's navy was destroyed, and his army was forced to retreat back to the north. The southern warlords had won a stunning victory, thanks to the ingenuity and courage of Zhu and you.",
    "Congratulations! You completed the restoration of this history~\n\nThanks for your outstanding contribution in the story!\n\nTake a look elsewhere if you want to learn more~",
    "Finally, Cao Cao unified the ancient China.\n\nThis is not true history, but you still made a distinguished contribution in the story.\n\nThanks for your participation.\n\nTake a look elsewhere if you want to learn more~"
]

let backgroundImageList = ["WinterCastle", "WinterArmy1", "Against1", "ZhuSitting", "LandWar", "ConfidentZhu","StrawBoat", "FireWar1", "FireWar2", "ZhuWin", "GoodEnding", "BadEnding"]

public var ThirdFloorKey: Int = 0

let models:[String] = ["spear", "bow", "flag", "armor"]

let descriptions: [(title: String, details: String)] = [
    (title: "Spear", details: "A common weapon, usually used by elite soldiers in the military. The spear's long shaft and sharp point make it an extremely powerful ranged weapon that can pierce through enemy armor and defenses."),
    (title: "Bow", details: "The Three Kingdoms period in China saw the widespread use of bows and arrows as crucial weaponry. Crafted from wood, bamboo, and animal sinew, these bows exhibited remarkable strength and precision. Arrows, often feathered and tipped with metal, enabled archers to effectively engage enemies in battle."),
    (title: "Flagpole", details: "During the Three Kingdoms period, military flags played a vital role in organizing and commanding troops. Soldiers would add colorful banners to flagpoles, helped identify various factions and conveyed strategic commands, significantly enhancing battlefield communication and cohesion."),
    (title: "Armor", details: "In the Three Kingdoms period, armor was essential for protecting soldiers during battle. Crafted from materials such as leather, iron, and bronze, these armors featured intricate designs and provided varying levels of coverage. Helmets, breastplates, and other protective gear offered crucial defense against enemy attacks.")
]

let Notice : String = "1. Welcome to the Eighth History Museum, where we journey back to ancient China's captivating Three Kingdoms period. Since this is a digital museum, where each module represents a unique exhibition hall, feel free to embark on a journey of discovery through each hall.\n\n2. Though I've tailored the museum for various screen sizes, the optimal experience awaits on an iPad, viewed vertically and in full screen.\n\n3. The enchanting melodies you hear are Chinese style tunes, masterfully performed by our musicians on the traditional instruments Guzheng and Dizi, blended with modern instruments. Feel free to provide feedback on the volume to musicians in Setting anytime, ensuring the perfect auditory experience.\n\n4. As you explore the Three Kingdoms period in our theater, you'll have the power to shape history. Choose wisely, for altering the past is no small feat!\n\n5. Just kidding! Relax, your decisions won't actually change history.\n\n6. To enjoy our AR exhibition hall, ensure your device supports AR and grant camera access for an immersive experience with our models.\n\n7. If AR isn't your device's forte, fret not! Pop over to the VR exhibition next door, where the same cultural treasures are on display.\n\n8. The Pavilion Hall on the third floor seems locked—perhaps a key is needed for entry?\n\n9. Our cleaning staff mentioned the curator may have misplaced something in the Kingdom of Shu's Celebrity Hall on the second floor last week."
