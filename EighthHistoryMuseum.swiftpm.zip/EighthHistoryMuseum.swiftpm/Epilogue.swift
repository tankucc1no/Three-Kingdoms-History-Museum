//
//  ThirdFloor.swift
//  weatherAI
//
//  Created by 侯天阔 on 2023/4/10.
//

import SwiftUI

struct ThirdFloor: View {
    @State private var showAlert = false
    var body: some View {
        if ThirdFloorKey == 0 {
            
            ZStack{
                Image("LockedDoor")
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
                    .opacity(0.9)
                HStack{
                    Spacer()
                        .frame(width: 100)
                    
                    VStack (alignment: .center,spacing: 30) {
                        Text("Locked door")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                    
                        Text("The third floor appears to be locked. The key must be hidden somewhere in the museum.")
                            .foregroundColor(.white)
       
                    }
                    .padding(.vertical, 80)
                    .padding(.horizontal, 30)
                    .background(Color.black.opacity(0.5))
                    .cornerRadius(30)///vstack end here
                    
                    Spacer()
                        .frame(width: 100)
                    
                }

            }
            
        } else {
            ZStack{
                Image("background5")
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
                    .opacity(0.9)
                
                HStack{
                    Spacer()
                        .frame(width: 100)
                    
                    VStack{
                        Spacer()
                            .frame(height: 100)
                        
                        VStack{
                            Button(action: {
                                showAlert = true
                            }) {
                                Image("author")
                                    .resizable()
                                    .cornerRadius(30)
                                    .aspectRatio(contentMode: .fit)
                                    .frame(minWidth: 40, idealWidth: 360, maxWidth: 360, minHeight: 30, idealHeight: 270, maxHeight: 270)
                            }
                            .alert(isPresented: $showAlert) {
                                Alert(title: Text("This is another easter egg"),
                                      message: Text("The reason why the museum is called the Eighth History Museum is because the Three Kingdoms period is the eighth period in Chinese history."),
                                      primaryButton: .default(Text("Cool!"), action: {
                                }),
                                      secondaryButton: .default(Text("That's awesome!!!"), action: {
                                }))
                                
                            }     
                            
                            Text("Author with ancient building")
                                .font(.largeTitle)
                                .foregroundColor(.white)
                            
                            
                            ScrollView(.vertical){
                                Text("Hooray! You've stumbled upon this hidden gem—a delightful easter egg. This snapshot captures my journey through the enchanting world of ancient Chinese architecture.\n\nHistory whispers enchanting tales of passion and bravery, where hearts intertwine and destinies unfold like a delicate dance, weaving a tapestry of human spirit, eternally captivating our souls. Exploring history has always been one of the things I enjoy doing and that's the reason why I made this program.\n\nI aspire to spark curiosity about this fascinating chapter of Chinese history through this program, encouraging more people to delve into history. To achieve this, I've enriched the historical presentation with interactive elements and freedom of movement, allowing users to feel immersed in the past. Regrettably, file size constraints led me to omit substantial portions of the storyline and interactive features, like the Chain Link, from the first-floor exhibition hall. Nevertheless, these captivating stories remain an integral part of Chinese history, and I encourage you to explore them further online or through other avenues if they pique your interest.\n\nThanks for being here. I hope you had an enjoyable visit, and I look forward to seeing you in next story!")
                                    .foregroundColor(.white)
                            }
                            
                            
                        }
                        .padding(.vertical, 80)
                        .padding(.horizontal, 30)
                        .background(Color.black.opacity(0.5))
                        .cornerRadius(30)///inside vstack end here
                        
                        Spacer()
                            .frame(height: 100)
                        
                    }
               
                    Spacer()
                        .frame(width: 100)
                }
            }
        }
    }
}

struct ThirdFloor_Previews: PreviewProvider {
    static var previews: some View {
        ThirdFloor()
    }
}
