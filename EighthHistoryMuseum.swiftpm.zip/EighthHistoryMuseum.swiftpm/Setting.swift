import SwiftUI
import AVFoundation
import Foundation

///bgm
class AudioPlayer {
    static let shared = AudioPlayer()
    private var audioPlayer: AVAudioPlayer?
    
    func playBackgroundMusic(filename:String = "BGM", fileType: String = "mp3") {
        if let bundle = Bundle.main.path(forResource: filename, ofType: fileType) {
            let backgroundMusic = URL(fileURLWithPath: bundle)
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: backgroundMusic)
                audioPlayer?.numberOfLoops = -1
                audioPlayer?.prepareToPlay()
                audioPlayer?.play()
            } catch {
                print(error)
            }
        }
    }
    
    func setVolume(volume: Float) {
        audioPlayer?.volume = volume
    }
    
    func toggleMute() {
        if let player = audioPlayer {
            player.volume = player.volume == 0 ? 1.0 : 0
        }
    }
    
    func isMuted() -> Bool {
        return audioPlayer?.volume == 0
    }
}


struct SettingsView: View {
    @State private var volume: Double = 0.5
    @State private var isMuted: Bool = false
    @State private var previousVolume: Double = 0.5
    
    private func volumeIcon() -> String {
        if isMuted {
            return "speaker.slash.fill"
        } else if volume > 0.7 {
            return "speaker.3.fill"
        } else if volume > 0.3 {
            return "speaker.2.fill"
        } else {
            return "speaker.1.fill"
        } 
    }
    
    var body: some View {
        ZStack{
            Image("BGM")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            HStack{
                Spacer()
                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
                
                VStack(spacing: 30) {
                    Text("Volume")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                    
                    Slider(value: $volume, in: 0...1, step: 0.01, onEditingChanged: { _ in
                        AudioPlayer.shared.setVolume(volume: Float(volume))
                        isMuted = (volume == 0)
                    })
                    .padding()
                    .accentColor(.orange)
                    
                    Button(action: {
                        if isMuted {
                            volume = previousVolume
                        } else {
                            previousVolume = volume
                            volume = 0
                        }
                        isMuted.toggle()
                        AudioPlayer.shared.setVolume(volume: Float(volume))
                    }) {
                        Image(systemName: volumeIcon())
                            .font(.system(size: 40))
                            .foregroundColor(.orange)
                    }
                    Text("Note: Should you find the musicians unresponsive to your conducting (unable to adjust the volume) or the music sounds chaotic and disorganized, it's probably due to Playground's automatic background code compilation. To resolve this, simply mute the volume in Playground's compilation interface or stop compilation process. (Sometimes it happens. It's a bug of Swift Playground I guess.)")
                        .foregroundColor(.white)
                }
                .padding(.vertical, 80)
                .padding(.horizontal, 30)
                .background(Color.black.opacity(0.5))
                .cornerRadius(30)///vstack end here
                
                Spacer()
                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
                
            }
        }
        
    }
}
