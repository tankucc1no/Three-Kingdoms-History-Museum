//
//  VRNavigation.swift
//  weatherAI
//
//  Created by 侯天阔 on 2023/4/8.
//
import SwiftUI
import SceneKit

struct VRModelView: View {
    
    @Binding var isplacementEnabel: Bool
    var model: String
    var description: (title: String, details: String)

    var body: some View {
        ZStack {
            Image("background6")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
                .opacity(0.9)

            HStack {
                Spacer()
                    .frame(width: 30)
                VStack(alignment: .center, spacing: 50) {
                    Text(description.title)
                        .font(.title)
                        .foregroundColor(.white)
                    Text(description.details)
                        .font(.body)
                        .foregroundColor(.white)
                    Button(
                    action: {
                        self.isplacementEnabel = false
                    }, label: {
                        Image(systemName: "chevron.backward")
                            .frame(width: 60, height: 60)
                            .font(.title)
                            .background(Color.white.opacity(0.75))
                            .cornerRadius(30)
                            .padding(20)
                    })
                }
                .padding()
                .frame(maxWidth: UIScreen.main.bounds.width / 3)
                .background(Color.black.opacity(0.5))
                .cornerRadius(30)
                .padding(/*@START_MENU_TOKEN@*/.vertical, 100.0/*@END_MENU_TOKEN@*/)
                
                Spacer()
                    .frame(width: 30)
                
                VStack{
                    Spacer()
                        .frame(height: 30)
                    SceneViewContainer(model: model)
                    Spacer()
                        .frame(height: 30)
                    
                }
                .background(Color.black.opacity(0.5))
                .cornerRadius(30)
                Spacer()
                    .frame(width: 30)
            }
        }
    }
}


struct SceneViewContainer: UIViewRepresentable {
    var model: String

    func makeUIView(context: Context) -> SCNView {
        let sceneView = SCNView(frame: .zero)
        let scene = SCNScene()
        sceneView.scene = scene
        sceneView.allowsCameraControl = true
        sceneView.autoenablesDefaultLighting = true
        sceneView.backgroundColor = .clear
        
        if let modelScene = try? SCNScene(named: model + ".usdz") {
            let modelNode = modelScene.rootNode.childNodes.first
            scene.rootNode.addChildNode(modelNode!)
        }

        return sceneView
    }

    func updateUIView(_ uiView: SCNView, context: Context) {}
}

struct VRModelSelectionView: View {
    
    @State private var isplacementEnabel = false
    @State private var Index: Int?
    

    
    var body: some View {
        if self.isplacementEnabel {
            VRModelView(isplacementEnabel: self.$isplacementEnabel, model: models[Index!], description: descriptions[Index!])
        } else {
            ZStack{
                Image("background6")
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
                HStack{
                    Spacer()
                        .frame(width:30)
                    ZStack{
                        VStack (spacing: 50) {
                            Text("Armory")
                                .font(.largeTitle)
                                .fontWeight(.heavy)
                                .foregroundColor(.white)
                            ForEach(0..<2) { rowIndex in
                                HStack (spacing: 20) {
                                    ForEach(0..<2) { colIndex in
                                        let index = rowIndex * 2 + colIndex
                                        HStack {
                                            Button(action: {
                                                isplacementEnabel = true
                                                Index = index
                                            }, label: {
                                                Image(uiImage: UIImage(named: models[index])!)
                                                    .resizable()
                                                    .cornerRadius(30)
                                                    .aspectRatio(contentMode: .fit)
                                                    .frame(minWidth: 30, idealWidth: 170, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300)
                                            })
                                            .buttonStyle(PlainButtonStyle())
                                            
                                            VStack (alignment: .leading) {
                                                Text(descriptions[index].title)
                                                    .font(.largeTitle)
                                                    .foregroundColor(.white)
                                                
                                                ScrollView(.vertical){
                                                    Text(descriptions[index].details)
                                                        .font(.subheadline)
                                                        .foregroundColor(.white)
                                                }
                                                
                                            }
                                            .frame(minWidth: 30, idealWidth: 150, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300, alignment: .leading)
                                            .aspectRatio(contentMode: .fit)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    .padding(30)
                    .background(Color.black.opacity(0.5))
                    .cornerRadius(30)
                    Spacer()
                        .frame(width:30)
                }

            }
            
            
        }
  
    }
}
