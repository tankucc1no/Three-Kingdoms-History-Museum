//
//  Shu.swift
//  weatherAI
//
//  Created by 侯天阔 on 2023/4/7.
//

import SwiftUI

struct Wu: View {
    
    var body: some View {
        
        
        ZStack{
            Image("background3")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            HStack{
                
                Spacer()
                    .frame(width: 30)
                
                VStack(alignment: .leading){
                    
                    Text("Kindom Wu")
                        .font(.largeTitle)
                        .fontWeight(.heavy)
                        .foregroundColor(.white)
                    Color.black
                        .frame(maxWidth: .infinity, maxHeight: 5)
                    Text("Monarch")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.leading)
                        .foregroundColor(.white)
                    HStack{
                        Image("SunQ")
                            .resizable()
                            .cornerRadius(30)
                            .aspectRatio(contentMode: .fit)
                            .frame(minWidth: 30, idealWidth: 200, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300)
                        
                        VStack(alignment: .leading){
                            Text("Sun Quan")
                                .font(.largeTitle)
                                .multilineTextAlignment(.leading)
                                .foregroundColor(.white)
                            ScrollView(.vertical){
                                Text("A prominent warlord in the late Eastern Han dynasty and the founder of the state of Eastern Wu. He allied with Liu Bei to resist Cao Cao and played a vital role in the decisive victory at the Battle of Red Cliffs.")
                                    .foregroundColor(.white)
                            }
                        }
                        .frame(minWidth: 30, idealWidth: 170, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300, alignment: .leading)
                        .aspectRatio(contentMode: .fit)
                        
                    }
                    Color.black
                        .frame(maxWidth: .infinity, maxHeight: 5)
                    Text("General")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                    
                    ScrollView(.horizontal) {
                        HStack (spacing:30){
                            HStack{
                                Image("Zhou")
                                    .resizable()
                                    .cornerRadius(30)
                                    .aspectRatio(contentMode: .fit)
                                    .frame(minWidth: 30, idealWidth: 200, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300)
                                
                                VStack(alignment: .leading){
                                    Text("Zhou Yu")
                                        .font(.largeTitle)
                                        .multilineTextAlignment(.leading)
                                        .foregroundColor(.white)
                                    ScrollView(.vertical){
                                        Text("A strategist of Sun Quan and successfully persuaded Sun Quan to form an alliance with Liu Bei to resist Cao Cao. He also provided strategic advice to the allied forces during the Battle of Red Cliffs.")
                                            .foregroundColor(.white)
                                    }
                                }
                                .frame(minWidth: 30, idealWidth: 170, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300, alignment: .leading)
                                .aspectRatio(contentMode: .fit)
                            }
                            HStack{
                                Image("Lu")
                                    .resizable()
                                    .cornerRadius(30)
                                    .aspectRatio(contentMode: .fit)
                                    .frame(minWidth: 30, idealWidth: 200, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300)
                                
                                VStack(alignment: .leading){
                                    Text("Lu Su")
                                        .font(.largeTitle)
                                        .multilineTextAlignment(.leading)
                                        .foregroundColor(.white)
                                    ScrollView(.vertical){
                                        Text("A strategist of Sun Quan who successfully convinced Sun Quan to form an alliance with Liu Bei against Cao Cao. He also provided strategic counsel for the allied forces during the Battle of Red Cliffs")
                                            .foregroundColor(.white)
                                    }
                                }
                                .frame(minWidth: 30, idealWidth: 170, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300, alignment: .leading)
                                .aspectRatio(contentMode: .fit)
                            }
                        }
                    }
                }
                .padding(.vertical, 80)
                .padding(.horizontal, 30)
                .background(Color.black.opacity(0.5))
                .cornerRadius(30)///vstack end here
                
                Spacer()
                    .frame(width: 30)
        }
        }
    }
}

struct Wu_Previews: PreviewProvider {
    static var previews: some View {
        Wu()
    }
}
