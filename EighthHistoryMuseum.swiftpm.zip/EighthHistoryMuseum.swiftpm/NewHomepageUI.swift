//
//  NewHomepageUI.swift
//  weatherAI
//
//  Created by 侯天阔 on 2023/4/11.
//

import SwiftUI

struct NewHomepageUI: View {
    @AppStorage("showAlert") var showAlert: Bool = true
    @State private var isShowingAlert = false
    
    var body: some View {
        NavigationView {
            ZStack{
                Image("background")
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
                    .opacity(0.9)
            
                VStack(spacing: 20) {
                    
                    Text("Eigth History Museum")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                    
                    NavigationLink(destination: Introduction()) {
                        Text("Entry Notice")
                            .padding(.horizontal, 44)
                            .padding()
                            .foregroundColor(.white)
                            .background(Color.black)
                            .clipShape(Capsule())
                    }
                    .buttonStyle(PlainButtonStyle())

                    Group {
                        Text("First Floor")
                            .font(.headline)
                            .foregroundColor(Color(red: 0.7, green: 0.7, blue: 0.7))

                        NavigationLink(destination: ContentView()) {
                            Text("The Red Cliff Theatre")
                                .padding(.horizontal, 10)
                                .padding()
                                .foregroundColor(.white)
                                .background(Color.black)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(PlainButtonStyle())
                    }

                    Group {
                        Text("Second Floor")
                            .font(.headline)
                            .foregroundColor(Color(red: 0.7, green: 0.7, blue: 0.7))


                        NavigationLink(destination: ARContentView()) {
                            Text("AR Weapons Showroom")
                                .padding()
                                .foregroundColor(.white)
                                .background(Color.black)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(PlainButtonStyle())

                        NavigationLink(destination: VRModelSelectionView()) {
                            Text("VR Weapons Showroom")
                                .padding()
                                .foregroundColor(.white)
                                .background(Color.black)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(PlainButtonStyle())

                        NavigationLink(destination: FactionsView()) {
                            Text("Celebrities Hall")
                            .padding(.horizontal, 36)
                                .padding()
                                .foregroundColor(.white)
                                .background(Color.black)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(PlainButtonStyle())
                    }

                    Group {
                        Text("Third Floor")
                            .font(.headline)
                            .foregroundColor(Color(red: 0.7, green: 0.7, blue: 0.7))

                        NavigationLink(destination: ThirdFloor()) {
                            Text("Pavilion Hall")
                                .padding(.horizontal, 48)
                                .padding()
                                .foregroundColor(.white)
                                .background(Color.black)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                    
                    Group {
                        Text("Setting")
                            .font(.headline)
                            .foregroundColor(Color(red: 0.7, green: 0.7, blue: 0.7))
                        
                        NavigationLink(destination: SettingsView()) {
                            Text("Sound")
                                .padding(.horizontal, 70)
                                .padding()
                                .foregroundColor(.white)
                                .background(Color.black)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(PlainButtonStyle())
                    }

                    
                }
                .padding(/*@START_MENU_TOKEN@*/.vertical, 50.0/*@END_MENU_TOKEN@*/)
                .padding(.horizontal, 30)
                .background(Color.black.opacity(0.5))
                .cornerRadius(30)
                
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .onAppear {
            if showAlert {
                isShowingAlert = true
            }
        }
        .alert(isPresented: $isShowingAlert) {
            Alert(title: Text("Note"),
                  message: Text("Please visit this museum in portrait and full screen.\n\nRead the Entry Notice before entering the museum."),
                  dismissButton: .default(Text("Confirm")) 
            )
        }
    }
}

