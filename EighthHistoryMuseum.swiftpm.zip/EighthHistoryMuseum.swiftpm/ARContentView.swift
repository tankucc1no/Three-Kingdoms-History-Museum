//
//  ARtest.swift
//  weatherAI
//
//  Created by 侯天阔 on 2023/4/7.
//

import SwiftUI
import RealityKit
import ARKit


///ContentView
struct ARContentView: View {
    
    @State private var isplacementEnabel = false
    @State private var seletedModel: String?
    @State private var confirmModel: String?
    

    var body: some View {
        
        ZStack(alignment: .bottom){
            
            ARContainer(confirmModel: self.$confirmModel)
            
            if self.isplacementEnabel{
                ComfirmationView(isplacementEnabel: self.$isplacementEnabel, selectedModel: self.$seletedModel, confirmedModel: $confirmModel)
            }else{
                ModelSelection(models: models, descriptions: descriptions, isplacementEnabel: self.$isplacementEnabel, selectedModel: $seletedModel)
            }
        }
    }
}


struct ARContainer: UIViewRepresentable{
    @Binding var confirmModel:String?
    
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal, .vertical]
        config.environmentTexturing = .automatic
        if ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh){
            config.sceneReconstruction = .mesh
        }
        
        arView.session.run(config)
        
        return arView
    }
    func updateUIView(_ uiView: ARView, context: Context) {
        if let modelName = self.confirmModel{
            let filename = modelName + ".usdz"
            let modelEntiy = try!ModelEntity.loadModel(named: filename)
            let anchorEntity = AnchorEntity(plane: .any)
            anchorEntity.addChild(modelEntiy)
            uiView.scene.addAnchor(anchorEntity)
            
            DispatchQueue.main.async {
                self.confirmModel = nil
            }
            
        }
    }
}

struct ModelSelection: View {
    
    var models:[String]
    var descriptions: [(title: String, details: String)]
    @Binding var isplacementEnabel: Bool
    @Binding var selectedModel: String?
    @State private var isVStackHidden = false

    var body: some View {
        VStack {
            Button(action: {
                withAnimation(.easeInOut(duration: 0.3)) {
                    isVStackHidden.toggle()
                }
            }, label: {
                Text(isVStackHidden ? "Tap here to show" : "Tap here to hide")
                    .foregroundColor(.white)
                    .padding()
            })

            if !isVStackHidden {
                Text("Tap icon to select a exhibit")
                    .foregroundColor(.white)
                
                ScrollView(.horizontal){
                    HStack(spacing:30){
                        ForEach(0 ..< Int(self.models.count)){
                            index in VStack {
                                Button(action: {
                                    self.isplacementEnabel = true
                                    self.selectedModel = self.models[index]
                                }, label: {
                                    Image(uiImage: UIImage(named: self.models[index])!)
                                        .resizable()
                                        .frame(width: 120, height: 160)
                                        .aspectRatio(3 / 4, contentMode: .fit)
                                        .background(Color.white)
                                        .cornerRadius(30)
                                })
                                .buttonStyle(PlainButtonStyle())

                                Text(self.descriptions[index].title)
                                    .font(.headline)
                                    .foregroundColor(.white)
                                ScrollView(.vertical){
                                    Text(self.descriptions[index].details)
                                    .font(.subheadline)
                                    .multilineTextAlignment(.center)
                                    .foregroundColor(.white)
                                }
                                .frame(width: UIScreen.main.bounds.width / 5, height: UIScreen.main.bounds.height / 4, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                                .transition(.move(edge: .leading))
                                
                            }
                        }
                    }
                }
            }
        }
        .padding(20)
        .background(Color.black.opacity(0.5))
        .cornerRadius(isVStackHidden ? 30 : 0) 
        .animation(.easeInOut(duration: 0.3), value: isVStackHidden)
    }
}


struct ComfirmationView : View{
    
    @Binding var isplacementEnabel: Bool
    @Binding var selectedModel: String?
    @Binding var confirmedModel: String?
    
    var body: some View{
        HStack{
            Button(action:{
                self.isplacementEnabel = false
                self.selectedModel = nil
            }){
                Image(systemName: "xmark")
                    .frame(width: 60, height: 60)
                    .font(.title)
                    .background(Color.white.opacity(0.75))
                    .cornerRadius(30)
                    .padding(20)
            }
            ///confirm button
            Text("Please aim at a flat surface to place the exhibit and tap tick to generate!")
            .foregroundColor(.white)
            
            Button(action:{
                self.confirmedModel = self.selectedModel
                self.isplacementEnabel = false
                self.selectedModel = nil
                
            }){
                Image(systemName: "checkmark")
                    .frame(width: 60, height: 60)
                    .font(.title)
                    .background(Color.white.opacity(0.75))
                    .cornerRadius(30)
                    .padding(20)
            }
        }
        .padding(20)
        .background(Color.black.opacity(0.5))
        .cornerRadius(30)
        
    }
    
}
