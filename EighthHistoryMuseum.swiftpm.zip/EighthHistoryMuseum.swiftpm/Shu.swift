//
//  Shu.swift
//  weatherAI
//
//  Created by 侯天阔 on 2023/4/7.
//

import SwiftUI

struct Shu: View {
    
    @State private var showAlert = false
    var body: some View {
        ZStack{
            Image("background3")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            HStack{
                Spacer()
                    .frame(width: 30)
                
                VStack(alignment: .leading){
                    
                    Text("Kindom Shu")
                        .font(.largeTitle)
                        .fontWeight(.heavy)
                        .foregroundColor(.white)
                    Color.black
                        .frame(maxWidth: .infinity, maxHeight: 5)
                    Text("Monarch")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.leading)
                        .foregroundColor(.white)
                    HStack{
                        Image("Liu")
                            .resizable()
                            .cornerRadius(30)
                            .aspectRatio(contentMode: .fit)
                            .frame(minWidth: 30, idealWidth: 200, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300)
                        VStack(alignment: .leading){
                            Text("Liu Bei")
                                .font(.largeTitle)
                                .multilineTextAlignment(.leading)
                                .foregroundColor(.white)
                            ScrollView(.vertical){
                                Text("A famous politician and military leader during the late Han Dynasty. He led the state of Shu Han in a struggle against the states of Cao Wei and Eastern Wu, ultimately establishing his own kingdom.\nHe participated in the Battle of Red Cliffs and, with the help of Zhuge Liang, established the Shu Han regime, making him one of the great figures in Chinese history.")
                                    .foregroundColor(.white)
                            }
                        }
                        .frame(minWidth: 30, idealWidth: 170, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300, alignment: .leading)
                        .aspectRatio(contentMode: .fit)
                        
                    }
                    Color.black
                        .frame(maxWidth: .infinity, maxHeight: 5)
                    Text("General")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                    
                    ScrollView(.horizontal) {
                        HStack (spacing:30){
                            HStack{
                                Image("ZhuGe")
                                    .resizable()
                                    .cornerRadius(30)
                                    .aspectRatio(contentMode: .fit)
                                    .frame(minWidth: 30, idealWidth: 200, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300)
                                
                                VStack(alignment: .leading){
                                    Text("Zhu Geliang")
                                        .font(.largeTitle)
                                        .multilineTextAlignment(.leading)
                                        .foregroundColor(.white)
                                    ScrollView(.vertical){
                                        Text("A strategist under Liu Bei's command. He was proficient in military strategy and provided advice and plans for Liu Bei during the Battle of Red Cliffs, which ultimately led to the victory of the allied forces.")
                                            .foregroundColor(.white)
                                    }
                                }
                                .frame(minWidth: 30, idealWidth: 170, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300, alignment: .leading)
                                .aspectRatio(contentMode: .fit)
                            }
                            HStack{
                                Image("Guan")
                                    .resizable()
                                    .cornerRadius(30)
                                    .aspectRatio(contentMode: .fit)
                                    .frame(minWidth: 30, idealWidth: 200, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300)
                                
                                VStack(alignment: .leading){
                                    Text("Guan Yu")
                                        .font(.largeTitle)
                                        .multilineTextAlignment(.leading)
                                        .foregroundColor(.white)
                                    ScrollView(.vertical){
                                        Text("An important general under Liu Bei's command. He led a small group of soldiers to attack the supply line of Cao Cao's army in the Battle of Red Cliffs, successfully burning their provisions and intensifying the plight of Cao Cao's army.")
                                            .foregroundColor(.white)
                                    }
                                }
                                .frame(minWidth: 30, idealWidth: 170, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300, alignment: .leading)
                                .aspectRatio(contentMode: .fit)
                            }
                            HStack{
                                Image("Zhao")
                                    .resizable()
                                    .cornerRadius(30)
                                    .aspectRatio(contentMode: .fit)
                                    .frame(minWidth: 30, idealWidth: 200, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300)
                                
                                VStack(alignment: .leading){
                                    Text("Zhao Yun")
                                        .font(.largeTitle)
                                        .multilineTextAlignment(.leading)
                                        .foregroundColor(.white)
                                    ScrollView(.vertical){
                                        Text("An important general under Liu Bei. He served as a vanguard in the Battle of Red Cliffs and successively captured two gates of the enemy's camp, demonstrating his remarkable performance in the battle.")
                                            .foregroundColor(.white)
                                    }
                                }
                                .frame(minWidth: 30, idealWidth: 170, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300, alignment: .leading)
                                .aspectRatio(contentMode: .fit)
                            }
                            HStack{
                                Button(action: {
                                    showAlert = true
                                    ThirdFloorKey += 1
                                }, label: {
                                    Image("key")
                                        .resizable()
                                        .cornerRadius(30)
                                        .aspectRatio(contentMode: .fit)
                                        .frame(minWidth: 30, idealWidth: 200, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300)
                                })
                                .alert(isPresented: $showAlert) {
                                          Alert(
                                              title: Text("Note"),
                                              message: Text(alertMessage()),
                                              dismissButton: .default(Text("Great!"))
                                          )
                                      }
                                
                                VStack(alignment: .leading){
                                    Text("Strange corner")
                                        .font(.largeTitle)
                                        .multilineTextAlignment(.leading)
                                        .foregroundColor(.white)
                                    ScrollView(.vertical){
                                        Text("Seems to be hiding something.")
                                            .foregroundColor(.white)
                                    }
                                }
                                .frame(minWidth: 30, idealWidth: 170, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300, alignment: .leading)
                                .aspectRatio(contentMode: .fit)
                            }

                        }
                    }
                }
                .padding(.vertical, 80)
                .padding(.horizontal, 30)
                .background(Color.black.opacity(0.5))
                .cornerRadius(30)///vstack end here
                
                Spacer()
                    .frame(width: 30)
            }
        }
    }
}

private func alertMessage() -> String {
    return ThirdFloorKey == 1 ? "Congratulations! You found the key." : "You have got the key."
}
