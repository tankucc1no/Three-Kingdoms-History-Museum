//
//  Characters.swift
//  weatherAI
//
//  Created by 侯天阔 on 2023/4/7.
//

import SwiftUI



struct Wei: View {
    
    
    var body: some View {
        ZStack{
            Image("background3")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
            
            HStack{
                Spacer()
                    .frame(width: 30)
                VStack(alignment: .leading){
                    Text("Kindom Wei")
                        .font(.largeTitle)
                        .fontWeight(.heavy)
                        .foregroundColor(.white)
                    Color.black
                        .frame(maxWidth: .infinity, maxHeight: 5)
                    Text("Monarch")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.leading)
                        .foregroundColor(.white)
                    HStack{
                        Image("Cao")
                            .resizable()
                            .cornerRadius(30)
                            .aspectRatio(contentMode: .fit)
                            .frame(minWidth: 30, idealWidth: 200, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300)
                        
                        VStack(alignment: .leading){
                            Text("Cao Cao")
                                .font(.largeTitle)
                                .foregroundColor(.white)
                            ScrollView(.vertical){
                                Text("A renowned warlord in ancient China, who played a pivotal role in the end of the Han Dynasty and the establishment of the Three Kingdoms period.")
                                    .foregroundColor(.white)
                            }
                        }
                        .frame(minWidth: 30, idealWidth: 170, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300, alignment: .leading)
                        .aspectRatio(contentMode: .fit)
                    }
                    Color.black
                        .frame(maxWidth: .infinity, maxHeight: 5)
                    Text("General")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                    
                    ScrollView(.horizontal) {
                        HStack(spacing:30) {
                            HStack{
                                Image("Zhang")
                                    .resizable()
                                    .cornerRadius(30)
                                    .aspectRatio(contentMode: .fit)
                                    .frame(minWidth: 30, idealWidth: 200, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300)
                                
                                VStack(alignment: .leading){
                                    Text("Zhang Liao")
                                        .font(.largeTitle)
                                        .multilineTextAlignment(.leading)
                                        .foregroundColor(.white)
                                    ScrollView(.vertical){
                                        Text("An important general under Cao Cao's command, who served as the vanguard in the Battle of Red Cliffs. He led Cao's army to launch fierce attacks against the allied forces, and repelled several counterattacks with great success.")
                                            .foregroundColor(.white)
                                    }
                                }
                                .frame(minWidth: 30, idealWidth: 170, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300, alignment: .leading)
                                .aspectRatio(contentMode: .fit)
                            }
                            HStack{
                                Image("Xu")
                                    .resizable()
                                    .cornerRadius(30)
                                    .aspectRatio(contentMode: .fit)
                                    .frame(minWidth: 30, idealWidth: 200, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300)
                                
                                VStack(alignment: .leading){
                                    Text("Xu Chu")
                                        .font(.largeTitle)
                                        .multilineTextAlignment(.leading)
                                        .foregroundColor(.white)
                                    ScrollView(.vertical){
                                        Text("An important general under Cao Cao. He was seven feet tall and extremely strong. In the Battle of Red Cliffs, he led Cao Cao's army to attack the allied forces with great force, and successfully broke through their defenses. Although Wei did not ultimately win the battle, the performance of these generals demonstrated the strength and combat capability of the Wei army.")
                                            .foregroundColor(.white)
                                    }
                                }
                                .frame(minWidth: 30, idealWidth: 170, maxWidth: 200, minHeight: 50, idealHeight: 300, maxHeight: 300, alignment: .leading)
                                .aspectRatio(contentMode: .fit)
                            }
                        }
                    }
                }
                .padding(.vertical, 80)
                .padding(.horizontal, 30)
                .background(Color.black.opacity(0.5))
                .cornerRadius(30)
                ///vstack end here
                Spacer()
                    .frame(width: 30)
            }
        }
        
    }
}



struct Characters_Previews: PreviewProvider {
    static var previews: some View {
        Wei()
    }
}
