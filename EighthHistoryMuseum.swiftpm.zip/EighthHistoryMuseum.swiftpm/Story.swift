//
//  AainView.swift
//  weatherAI
//
//  Created by 侯天阔 on 2023/4/5.
//

import SwiftUI

struct ContentView: View {
    
    @State private var backgroundImage:String = "background"
    @State private var section:Int = 0
    @State private var selectionmood = false
    @State private var ending = false
    
    let sectionMax = 11


    var body: some View {
        if section < 10{

            if !selectionmood{
                
                ZStack {
                    Image(backgroundImageList[section])
                        .resizable()
                        .scaledToFill()
                        .edgesIgnoringSafeArea(.all)
                        
                    VStack{
                        Spacer(minLength: 50)
                        
                        HStack{
                            Spacer(minLength: UIScreen.main.bounds.width / 8)
                            ZStack {
                                Color.black.opacity(0.4)
                                    .cornerRadius(30)
                                VStack(alignment: .center, content: {
                                    Spacer()
                                    ScrollView {
                                        Text(subtitleLines[section])
                                            .font(.title)
                                            .padding()
                                            .foregroundColor(Color.white) 
                                    }
                                    Spacer()
                                 })
                                
                            }
                            .frame(minWidth: 200, idealWidth: 400, maxWidth: 500, minHeight: 200, idealHeight: 500, maxHeight: 600, alignment: .center)
                            Spacer(minLength: UIScreen.main.bounds.width / 8)
                        }
                        
                        if section != 0 && section != 5{
                            if section == 3{
                                HStack{
                                    Button(action: {
                                            self.section -= 1
                                            self.backgroundImage = backgroundImageList[section]
                                   
                                    }) {
                                        Text("I'm not ready")
                                            .frame(width: UIScreen.main.bounds.width / 4, height: 30)
                                            .font(.title)
                                            .foregroundColor(.black)
                                            .padding()
                                            .background(Color.yellow)
                                            .clipShape(Capsule())
                                    }
                                    
                                    Button(action: {
                                        if section != sectionMax{
                                            self.section += 1
                                            self.selectionmood = true
                                        }
                                        
                                    }) {
                                        Text("It's a tough choice")
                                            .frame(width: UIScreen.main.bounds.width / 4 + 20, height: 30)
                                            .font(.title)
                                            .foregroundColor(.black)
                                            .padding()
                                            .background(Color.yellow)
                                            .clipShape(Capsule())
                                    }
                                }
                            } else if section == 4{
                                VStack{
                                    Button(action: {
                                            self.section = 11
                                            self.backgroundImage = backgroundImageList[section]
                                   
                                    }) {
                                        Text("Great, I am the fan of Cao anyway~")
                                            .frame(width: UIScreen.main.bounds.width / 2 + 20, height: 30)
                                            .font(.title)
                                            .foregroundColor(.black)
                                            .padding()
                                            .background(Color.yellow)
                                            .clipShape(Capsule())
                                    }
                                    
                                    Button(action: {
                                        if section != sectionMax{
                                            self.selectionmood = true
                                        }
                                        
                                    }) {
                                        Text("No way! Let my try again.")
                                            .frame(width: UIScreen.main.bounds.width / 2, height: 30)
                                            .font(.title)
                                            .foregroundColor(.black)
                                            .padding()
                                            .background(Color.orange)
                                            .clipShape(Capsule())
                                    }
                                }
                            } else {
                                HStack{
                                    Button(action: {
                                            self.section -= 1
                                            self.backgroundImage = backgroundImageList[section]
                                   
                                    }) {
                                        Text("Previous")
                                            .frame(width: UIScreen.main.bounds.width / 6, height: 30)
                                            .font(.title)
                                            .foregroundColor(.black)
                                            .padding()
                                            .background(Color.yellow)
                                            .clipShape(Capsule())
                                    }
                                    
                                    Button(action: {
                                        if section != sectionMax{
                                            self.section += 1
                                            self.backgroundImage = backgroundImageList[section]
                                        }
                                        
                                    }) {
                                        Text("Next")
                                            .frame(width: UIScreen.main.bounds.width / 6, height: 30)
                                            .font(.title)
                                            .foregroundColor(.black)
                                            .padding()
                                            .background(Color.yellow)
                                            .clipShape(Capsule())
                                    }
                                }
                            }
                            
                        } else {
                            Button(action: {
                                if section != sectionMax{
                                    self.section += 1
                                    self.backgroundImage = backgroundImageList[section]
                                }
                            }) {
                                Text("Next")
                                    .frame(width: UIScreen.main.bounds.width / 6, height: 30)
                                    .font(.title)
                                    .foregroundColor(.black)
                                    .padding()
                                    .background(Color.yellow)
                                    .clipShape(Capsule())
                            }
                        }
                        
                    Spacer(minLength: 200)
                    }
                }
                    
            } else {
                VStack(spacing: 0){
                    ZStack{
                        Image("ZhouY")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .clipped()
                            .edgesIgnoringSafeArea(.all)
                        
                        VStack{
                            ZStack{
                                Color.black.opacity(0.5)
                                    .cornerRadius(30)
                                    
                                Text("At this time you will choose:")
                                    .font(.largeTitle)
                                    .fontWeight(.heavy)
                                    .foregroundColor(Color.white)
                            }
                            .frame(minWidth: 100, idealWidth: UIScreen.main.bounds.width / 2, maxWidth: UIScreen.main.bounds.width / 3 * 2,maxHeight: 100, alignment: .center)
                            
                            ZStack {
                                Color.black.opacity(0.4)
                                    .cornerRadius(30)
                                    .padding(.horizontal, UIScreen.main.bounds.width / 10)
                                    .padding(.vertical, 60.0)
                                    
                                    
                                Text("Abandon the fiery assault and dispatch the elite troops to storm the beachhead.")
                                    .font(.title)
                                    .padding(.horizontal, UIScreen.main.bounds.width / 10)
                                    .padding(/*@START_MENU_TOKEN@*/.vertical, 60.0/*@END_MENU_TOKEN@*/)
                                    .foregroundColor(Color.white)
                            }
                            .frame(minWidth: 200, idealWidth: UIScreen.main.bounds.height / 2, maxWidth: UIScreen.main.bounds.height / 2, maxHeight: UIScreen.main.bounds.height / 3, alignment: .center)
                            Button(action: {
                                self.selectionmood = false
                                self.section = 4
                            }) {
                                Text("Follow the Zhou Yu")
                                    .frame(width: UIScreen.main.bounds.width / 3, height: 30)
                                    .font(.title)
                                    .foregroundColor(.black)
                                    .padding()
                                    .background(Color.yellow)
                                    .clipShape(Capsule())
                            }
                            Spacer(minLength: 50)
                                
                        }
                    }
                    
                    ZStack{
                        Image("ZhuHulf")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .clipped()
                            .edgesIgnoringSafeArea(.all)
                        VStack{
                            ZStack {
                                Color.black.opacity(0.4)
                                    .cornerRadius(30)
                                    .padding(.horizontal, UIScreen.main.bounds.width / 10)
                                    .padding(/*@START_MENU_TOKEN@*/.vertical, 60.0/*@END_MENU_TOKEN@*/)
                                    
                                    
                                Text("Attack with scarecrow to deceive the enemy's archers and steal the arrows.")
                                    .font(.title)
                                    .padding(.horizontal, UIScreen.main.bounds.width / 10)
                                    .padding(/*@START_MENU_TOKEN@*/.vertical, 60.0/*@END_MENU_TOKEN@*/)
                                    .foregroundColor(Color.white)
                            }
                            .frame(minWidth: 200, idealWidth: UIScreen.main.bounds.height / 2, maxWidth: UIScreen.main.bounds.height / 2, maxHeight: UIScreen.main.bounds.height / 3, alignment: .center)
                            Button(action: {
                                self.selectionmood = false
                                self.section = 5
                            }) {
                                Text("Follow the Zhu Geliang")
                                    .frame(width: UIScreen.main.bounds.width / 3, height: 30)
                                    .font(.title)
                                    .foregroundColor(.black)
                                    .padding()
                                    .background(Color.orange)
                                    .clipShape(Capsule())
                            }
                            Spacer(minLength: 50)
                        }
                    }
                }
            } ///else end here
            
        } else {
            ZStack {
                Image(backgroundImageList[section])
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
                
                VStack{
                    Spacer(minLength: 200)
                    
                    HStack{
                        Spacer(minLength: UIScreen.main.bounds.width / 8)
                        ZStack {
                            Color.black.opacity(0.4)
                                .cornerRadius(30)
                            Text(subtitleLines[section])
                                .font(.title)
                                .padding()
                                .foregroundColor(Color.white)
                        }
                        .frame(minWidth: 100, idealWidth: 400, maxWidth: 500, minHeight: 100, idealHeight: 500, maxHeight: 600, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)

                        Spacer(minLength: UIScreen.main.bounds.width / 8)
                    }
                    
                    Button(action: {
                        self.section = 0
                    }) {
                        Text("Participate again")
                            .frame(width: UIScreen.main.bounds.width / 3, height: 30)
                            .font(.title)
                            .foregroundColor(.black)
                            .padding()
                            .background(Color.yellow)
                            .clipShape(Capsule())
                    }
                    Spacer(minLength: UIScreen.main.bounds.width / 8)
                }
            }
        }
    } //body end here
}

